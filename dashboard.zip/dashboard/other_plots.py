import dash
import numpy as np
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import plotly.express as px

import pandas as pd

app = dash.Dash(__name__)
dataset = pd.read_csv('2015data.csv')
dataset_copy = pd.read_csv('2015data.csv')

all_variables= dataset.columns.unique()
all_forced_binary_variables = []
all_binary_variables = []
all_continuous_variables = []

#remove ?
for variable_in_question in all_variables:
    dataset = dataset[dataset[variable_in_question] != '?']

#take continious var
for variable_in_question in all_variables:
    if dataset[variable_in_question].dtypes == (np.int64 or np.int32 or np.int8 or np.float_) :
        values, counts = np.unique(dataset[variable_in_question], return_counts=True)
        if (len(values)<5 and len(values)>2):
            try:
                all_forced_binary_variables.append(variable_in_question)
                index_most_occuring = np.where(counts == max(counts))
                binary_value_1 = values[index_most_occuring][0]
                new_counts = np.delete(counts, np.where(counts == max(counts)))
                new_values = np.delete(values, np.where(values == binary_value_1))
                index_second_most_occuring = np.where(new_counts == max(new_counts))
                binary_value_2 = new_values[index_most_occuring][0]
                binary_variables = [binary_value_1, binary_value_2]
                dataset = dataset[dataset[variable_in_question].isin(binary_variables)]
                all_forced_binary_variables.append(variable_in_question)
            except Exception:
                continue
            finally:
                continue
        elif (len(values)>5):
            all_continuous_variables.append(variable_in_question)
        elif (len(values) == 2):
            all_binary_variables.append(variable_in_question)
        else:
            continue
    else:
        continue

app.layout = html.Div([
    html.Div([

        html.Div([
            dcc.Dropdown(
                id='xaxis-column',
                options=[{'label': i, 'value': i} for i in all_continuous_variables],
                value='Number_of_Casualties'
            ),
            dcc.RadioItems(
                id='xaxis-type',
                options=[{'label': i, 'value': i} for i in ['Linear', 'Log']],
                value='Linear',
                labelStyle={'display': 'inline-block'}
            )
        ], style={'width': '48%', 'display': 'inline-block'}),

        html.Div([
            dcc.Dropdown(
                id='yaxis-column',
                options=[{'label': i, 'value': i} for i in all_continuous_variables],
                value='Number_of_Casualties'
            ),
            dcc.RadioItems(
                id='yaxis-type',
                options=[{'label': i, 'value': i} for i in ['Linear', 'Log']],
                value='Linear',
                labelStyle={'display': 'inline-block'}
            )
        ], style={'width': '48%', 'float': 'right', 'display': 'inline-block'})
    ]),


    html.Div([
        dcc.Graph(id='indicator-graphic'),

        dcc.Slider(
            id='Number_of_Casualties',
            min=dataset['Number_of_Casualties'].min(),
            max=dataset['Number_of_Casualties'].max(),
            value= 2,
            marks={str(year): str(year) for year in dataset['Number_of_Casualties'].unique()},
            step=None
        )
    ]),

    html.Div([
        html.Div([
            dcc.Graph(id="distplot")
        ], style={'width': '60%', 'display': 'inline-block'}),
        html.Div([
            dcc.Graph(id='boxplot'),
            html.P("Select Distribution:"),
            dcc.RadioItems(
                id='dist-marginal',
                options=[{'label': x, 'value': x}
                         for x in ['box', 'violin']],
                value='box')
        ], style={'width': '40%', 'display': 'inline-block'}),

    ]),
])


@app.callback(
    Output('indicator-graphic', 'figure'),
    Input('xaxis-column', 'value'),
    Input('yaxis-column', 'value'),
    Input('xaxis-type', 'value'),
    Input('yaxis-type', 'value'),
    Input('Number_of_Casualties', 'value'))
def update_graph(xaxis_column_name, yaxis_column_name,
                 xaxis_type, yaxis_type,
                 Casualties_value):
    dff = dataset[dataset['Number_of_Casualties'] == Casualties_value]

    # fig = px.scatter(x=dff[dff[xaxis_column_name]]['Value'],
    #                  y=dff[dff[yaxis_column_name]]['Value'],
    #                  hover_name=dff[dff[xaxis_column_name]]['Country Name'])
    
    if ("Type" in str(xaxis_column_name)):
        fig = px.bar(dff, x=str(xaxis_column_name),
                        y=str(yaxis_column_name),
                        hover_name=str(yaxis_column_name),
                        color=dff['Accident_Severity'].astype(str),
                        title= 'Accident_Severity'
                        )       

    else:
        fig = px.scatter(dff, x=str(xaxis_column_name),
                        y=str(yaxis_column_name),
                        hover_name=str(yaxis_column_name),
                        color= 'Accident_Severity',
                        title= 'Accident_Severity',
                        size= 'Accident_Severity',
                        color_discrete_sequence=px.colors.qualitative.G10
                        )

    fig.update_layout(margin={'l': 40, 'b': 40, 't': 10, 'r': 0}, hovermode='closest')

    fig.update_xaxes(title=xaxis_column_name,
                     type='linear' if xaxis_type == 'Linear' else 'log')

    fig.update_yaxes(title=yaxis_column_name,
                     type='linear' if yaxis_type == 'Linear' else 'log')

    return fig

@app.callback(
    Output("distplot", "figure"),
    Input('xaxis-column', 'value'),
    Input('yaxis-column', 'value')
)
def display_graph(xaxis_column_name, yaxis_column_name):
    fig_go = go.Figure()
    fig_go.add_trace(go.Histogram(x=dataset[xaxis_column_name], name=xaxis_column_name))
    fig_go.add_trace(go.Histogram(x=dataset[yaxis_column_name], name=yaxis_column_name))
    # Overlay both histograms
    fig_go.update_layout(barmode='overlay')
    # Reduce opacity to see both histograms
    fig_go.update_traces(opacity=0.6)
    return fig_go

@app.callback(
    Output('boxplot', 'figure'),
    Input("dist-marginal", "value"),
    Input('xaxis-column', 'value'),
    Input('yaxis-column', 'value')
)
def another_graph(marginal, xaxis_column_name, yaxis_column_name):
    if marginal=='box':
        fig = px.box(dataset, [xaxis_column_name, yaxis_column_name])
    elif marginal=='violin':
        fig = px.violin(dataset, [xaxis_column_name, yaxis_column_name])
    return fig
#dataset['Number_of_Casualties']
#all_continuous_variables
#all_forced_binary_variables
#dataset['Accident_Severity'].astype(str)


if __name__ == '__main__':
    app.run_server(debug=True)

string = 'Condidtion'

'Condition' in string