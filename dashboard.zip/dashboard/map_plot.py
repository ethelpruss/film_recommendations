import os
from random import randint
import pandas as pd
import dash
import flask
from dash.dependencies import Input, Output, State
from dash import html
from dash import dcc
import plotly.graph_objects as go


from pandas import read_csv, DataFrame

df = pd.read_csv('accidents2015_V.csv', index_col = 0).dropna(how='any', axis = 0)
df['Hour'] = df['Time'].apply(lambda x: int(x[:2]))


def accidentMap(severity):

    token = 'pk.eyJ1IjoiYmxvYmJlcmlubyIsImEiOiJja3lwc3Rlb2gwNmYyMm50Z2NmYnJuZmUzIn0.enOkxCEYJ2qDj_qKkwP_Bw'
    map_colors = {'Slight' : 'rgba(255,224,132,0.7)', 'Serious' : 'rgba(249,139,96,0.7)', 'Fatal' : 'rgba(178,34,34,0.9)'}
    legend_colors = {'Slight' : 'rgb(255,224,132)', 'Serious' : 'rgb(249,139,96)', 'Fatal' : 'rgb(178,34,34)'}
    dark_style = 'mapbox://styles/blobberino/ckyptb5bmq0zv15pcqlyxd2nw'
    light_style = 'mapbox://styles/srepho/cjttho6dl0hl91fmzwyicqkzf'
    blue_style = 'mapbox://styles/blobberino/ckyrizkxqcy8815pcg5jjc6ec'
    # SLIGHT_FRAC = 0.5
    # SERIOUS_FRAC = 1
    #DAYSORT = dict(zip(['Friday', 'Monday', 'Saturday','Sunday', 'Thursday', 'Tuesday', 'Wednesday'],
    #             [4, 0, 5, 6, 3, 1, 2]))

    df_map = df[df['Accident_Severity'].isin(severity)]
    sample = df_map.sample(frac=0.4, replace=True, random_state=1)

    traces = []

    # too many data points for the map to handle. Downsampling to around 10k points max in each category
    for sev in sorted(severity, reverse=True):
            
        # This trace holds the data
        traces.append({
            'type' : 'scattermapbox',
            'mode' : 'markers',
            'lat' : sample['Latitude'][sample['Accident_Severity'] == sev],
            'lon' : sample['Longitude'][sample['Accident_Severity'] == sev],
            'marker' : {
                'color' : map_colors[sev],
                'size' : sample['Number_of_Casualties'][sample['Accident_Severity'] == sev],
            
            },
            'name' : sev,
            'legendgroup' : sev,
            'showlegend' : False,
            'hoverinfo' : 'text',
            'text' : sample['Local_Authority_(District)'],
        })
        
        # This trace is only for the legend items
        traces.append({
            'type' : 'scattermapbox',
            'mode' : 'markers',
            'lat' : [0],
            'lon' : [0],
            'marker' : {
                'color' : legend_colors[sev],
                'size' : 12,
                'opacity' : 1,
            },
            'name' : sev,
            'legendgroup' : sev,
        })
    
    layout = {
        'height' : 550,
        'width' : 400,
        'paper_bgcolor' : 'rgba(0,0,0,0)', 
        'autosize' : True,
        'hovermode' : 'closest',
        'legend_tracegroupgap' : 0,
        'mapbox' : {
            'accesstoken' : token,
            'center' : {
                'lat' : 54.7,
                'lon' : -4.2
            },
            'zoom' : 4.5,
            'style' : light_style,   
        },
        'margin' : {'t' : 0,
                   'b' : 0,
                   'l' : 0,
                   'r' : 0},
        'legend' : {  # Want to put the legend at the top
            'font' : {'color' : 'black', 'size' : 10},
             'orientation' : 'h',
             'x' : 0,
             'y' : 1,
             'yanchor' : 'bottom',
             'xanchor' : 'left',
             'traceorder' : 'reversed',
        }
    }

    fig = go.Figure(dict(data=traces, layout=layout))

    config = {'displayModeBar': True,
    'displaylogo': False, 'modeBarButtonsToRemove': ['lasso2d'], 'scrollZoom': True}
    #fig.show()
    fig = dict(data=traces, layout=layout, config = config) 
    return fig


#accidentMap(['Slight', 'Serious', 'Fatal'])
