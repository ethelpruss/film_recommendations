import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
import pandas as pd
import numpy as np
import dash
import dash_table
from dash_table.Format import Format, Group, Scheme
import dash_table.FormatTemplate as FormatTemplate
from datetime import datetime as dt
from app import app
import os
from random import randint
from dash.dependencies import Input, Output, State
import dash_core_components as dcc
import dash_html_components as html
import plotly.express as px
from pandas import read_csv, DataFrame
## IMPORT MAP DATA
df = pd.read_csv('data/accidents2015_V.csv')

## OTHER DATA

dataset = pd.read_csv('data/2015data.csv')
dataset_copy = pd.read_csv('data/2015data.csv')

all_variables= dataset.columns.unique()
all_forced_binary_variables = []
all_binary_variables = []
all_continuous_variables = []

#remove ?
for variable_in_question in all_variables:
    dataset = dataset[dataset[variable_in_question] != '?']

#take continious var
for variable_in_question in all_variables:
    if dataset[variable_in_question].dtypes == (np.int64 or np.int32 or np.int8 or np.float_) :
        values, counts = np.unique(dataset[variable_in_question], return_counts=True)
        if (len(values)<5 and len(values)>2):
            try:
                all_forced_binary_variables.append(variable_in_question)
                index_most_occuring = np.where(counts == max(counts))
                binary_value_1 = values[index_most_occuring][0]
                new_counts = np.delete(counts, np.where(counts == max(counts)))
                new_values = np.delete(values, np.where(values == binary_value_1))
                index_second_most_occuring = np.where(new_counts == max(new_counts))
                binary_value_2 = new_values[index_most_occuring][0]
                binary_variables = [binary_value_1, binary_value_2]
                dataset = dataset[dataset[variable_in_question].isin(binary_variables)]
                all_forced_binary_variables.append(variable_in_question)
            except Exception:
                continue
            finally:
                continue
        elif (len(values)>5):
            all_continuous_variables.append(variable_in_question)
        elif (len(values) == 2):
            all_binary_variables.append(variable_in_question)
        else:
            continue
    else:
        continue



####################################################################################################
# 000 - FORMATTING INFO
####################################################################################################

####################### Corporate css formatting
corporate_colors = {
    'dark-blue-grey' : 'rgb(62, 64, 76)',
    'medium-blue-grey' : 'rgb(77, 79, 91)',
    'superdark-green' : 'rgb(41, 56, 55)',
    'dark-green' : 'rgb(57, 81, 85)',
    'medium-green' : 'rgb(93, 113, 120)',
    'light-green' : 'rgb(186, 218, 212)',
    'pink-red' : 'rgb(255, 101, 131)',
    'dark-pink-red' : 'rgb(247, 80, 99)',
    'white' : 'rgb(251, 251, 252)',
    'light-grey' : 'rgb(208, 206, 206)'
}

externalgraph_rowstyling = {
    'margin-left' : '15px',
    'margin-right' : '15px'
}

externalgraph_colstyling = {
    'border-radius' : '10px',
    'border-style' : 'solid',
    'border-width' : '1px',
    'border-color' : corporate_colors['superdark-green'],
    'background-color' : corporate_colors['superdark-green'],
    'box-shadow' : '0px 0px 17px 0px rgba(186, 218, 212, .5)',
    'padding-top' : '10px'
}

filterdiv_borderstyling = {
    'border-radius' : '0px 0px 10px 10px',
    'border-style' : 'solid',
    'border-width' : '1px',
    'border-color' : corporate_colors['light-green'],
    'background-color' : corporate_colors['light-green'],
    'box-shadow' : '2px 5px 5px 1px rgba(255, 101, 131, .5)'
    }

navbarcurrentpage = {
    'text-decoration' : 'underline',
    'text-decoration-color' : corporate_colors['pink-red'],
    'text-shadow': '0px 0px 1px rgb(251, 251, 252)'
    }

recapdiv = {
    'border-radius' : '10px',
    'border-style' : 'solid',
    'border-width' : '1px',
    'border-color' : 'rgb(251, 251, 252, 0.1)',
    'margin-left' : '15px',
    'margin-right' : '15px',
    'margin-top' : '15px',
    'margin-bottom' : '15px',
    'padding-top' : '5px',
    'padding-bottom' : '5px',
    'background-color' : 'rgb(251, 251, 252, 0.1)'
    }

recapdiv_text = {
    'text-align' : 'left',
    'font-weight' : '350',
    'color' : corporate_colors['white'],
    'font-size' : '1.5rem',
    'letter-spacing' : '0.04em'
    }

####################### Corporate chart formatting

corporate_title = {
    'font' : {
        'size' : 16,
        'color' : corporate_colors['white']}
}

corporate_xaxis = {
    'showgrid' : False,
    'linecolor' : corporate_colors['light-grey'],
    'color' : corporate_colors['light-grey'],
    'tickangle' : 315,
    'titlefont' : {
        'size' : 12,
        'color' : corporate_colors['light-grey']},
    'tickfont' : {
        'size' : 11,
        'color' : corporate_colors['light-grey']},
    'zeroline': False
}

corporate_yaxis = {
    'showgrid' : True,
    'color' : corporate_colors['light-grey'],
    'gridwidth' : 0.5,
    'gridcolor' : corporate_colors['dark-green'],
    'linecolor' : corporate_colors['light-grey'],
    'titlefont' : {
        'size' : 12,
        'color' : corporate_colors['light-grey']},
    'tickfont' : {
        'size' : 11,
        'color' : corporate_colors['light-grey']},
    'zeroline': False
}

corporate_font_family = 'Dosis'

corporate_legend = {
    'orientation' : 'h',
    'yanchor' : 'bottom',
    'y' : 1.01,
    'xanchor' : 'right',
    'x' : 1.05,
	'font' : {'size' : 9, 'color' : corporate_colors['light-grey']}
} # Legend will be on the top right, above the graph, horizontally

corporate_margins = {'l' : 5, 'r' : 5, 't' : 45, 'b' : 15}  # Set top margin to in case there is a legend

corporate_layout = go.Layout(
    font = {'family' : corporate_font_family},
    title = corporate_title,
    title_x = 0.5, # Align chart title to center
    paper_bgcolor = 'rgba(0,0,0,0)',
    plot_bgcolor = 'rgba(0,0,0,0)',
    xaxis = corporate_xaxis,
    yaxis = corporate_yaxis,
    height = 270,
    legend = corporate_legend,
    margin = corporate_margins
    )

####################################################################################################
# 000 - DATA MAPPING
####################################################################################################

#Sales mapping
# sales_filepath = 'data/datasource.xlsx'

# sales_fields = {
#     'date' : 'Date',
#     'reporting_group_l1' : 'Country',
#     'reporting_group_l2' : 'City',
#     'sales' : 'Sales Units',
#     'revenues' : 'Revenues',
#     'sales target' : 'Sales Targets',
#     'rev target' : 'Rev Targets',
#     'num clients' : 'nClients'
#     }
# sales_formats = {
#     sales_fields['date'] : '%d/%m/%Y'
# }
####################################################################################################
# 000 - DEFINE ADDITIONAL FUNCTIONS
####################################################################################################
def group_wavg(df, gr_by_cols, weight, value):
    """This function returns a df grouped by the gr_by_cols and calculate the weighted avg based
    on the entries in the weight and value lists"""
    # Calculate weight * value columns
    wcols = []
    cols = []
    for i in range(0,len(value),1):
        wcol = "w"+value[i]
        wcols.append(wcol)
        df[wcol] = df[weight[i]] * df[value[i]]
    # Group by summing the wcols and weight columns
    cols = weight
    for i in wcols:
        cols.append(i)
    df1 = df.groupby(gr_by_cols)[cols].agg('sum')
    df1.reset_index(inplace=True)
    # Divide wcols by weight and remove columns
    for i in range(0,len(value),1):
        df1[value[i]] = df1[wcols[i]] / df1[weight[i]]
        df1.drop(wcols[i], axis='columns', inplace=True)

    return df1

def colorscale_generator(n, starting_col = {'r' : 186, 'g' : 218, 'b' : 212}, finish_col = {'r' : 57, 'g' : 81, 'b' : 85}):
    """This function generate a colorscale between two given rgb extremes, for an amount of data points
    The rgb should be specified as dictionaries"""
    r = starting_col['r']
    g = starting_col['g']
    b = starting_col['b']
    rf = finish_col['r']
    gf = finish_col['g']
    bf = finish_col['b']
    ri = (rf - r) / n
    gi = (gf - g) / n
    bi = (bf - b) / n
    color_i = 'rgb(' + str(r) +','+ str(g) +',' + str(b) + ')'
    my_colorscale = []
    my_colorscale.append(color_i)
    for i in range(n):
        r = r + ri
        g = g + gi
        b = b + bi
        color = 'rgb(' + str(round(r)) +','+ str(round(g)) +',' + str(round(b)) + ')'
        my_colorscale.append(color)

    return my_colorscale

# Create a corporate colorcale
colors = colorscale_generator(n=11)

corporate_colorscale = [
    [0.0, colors[0]],
    [0.1, colors[1]],
    [0.2, colors[2]],
    [0.3, colors[3]],
    [0.4, colors[4]],
    [0.5, colors[5]],
    [0.6, colors[6]],
    [0.7, colors[7]],
    [0.8, colors[8]],
    [0.9, colors[9]],
    [1.0, colors[10]]]

####################################################################################################
####################################################################################################
# 000 - IMPORT DATA
####################################################################################################
## IMPORT MAP DATA
df = pd.read_csv('data/accidents2015_V.csv')


# EXPLORE PAGE
####################################################################################################
####################################################################################################
####################################################################################################
@app.callback(
    Output('indicator-graphic', 'figure'),
    Input('xaxis-column', 'value'),
    Input('yaxis-column', 'value'),
    Input('xaxis-type', 'value'),
    Input('yaxis-type', 'value'),
    Input('Number_of_Casualties', 'value'))
def update_graph(xaxis_column_name, yaxis_column_name,
                 xaxis_type, yaxis_type,
                 Casualties_value):
    dff = dataset[dataset['Number_of_Casualties'] == Casualties_value]

    # fig = px.scatter(x=dff[dff[xaxis_column_name]]['Value'],
    #                  y=dff[dff[yaxis_column_name]]['Value'],
    #                  hover_name=dff[dff[xaxis_column_name]]['Country Name'])
    
    if ("Type" in str(xaxis_column_name)):
        fig = px.bar(dff, x=str(xaxis_column_name),
                        y=str(yaxis_column_name),
                        hover_name=str(yaxis_column_name),
                        color=dff['Accident_Severity'].astype(str),
                        title= 'Accident_Severity'
                        )       

    else:
        fig = px.scatter(dff, x=str(xaxis_column_name),
                        y=str(yaxis_column_name),
                        hover_name=str(yaxis_column_name),
                        color= 'Accident_Severity',
                        title= 'Accident_Severity',
                        size= 'Accident_Severity',
                        color_discrete_sequence=px.colors.qualitative.G10
                        )

    fig.update_layout(margin={'l': 40, 'b': 40, 't': 10, 'r': 0}, hovermode='closest')

    fig.update_xaxes(title=xaxis_column_name,
                     type='linear' if xaxis_type == 'Linear' else 'log')

    fig.update_yaxes(title=yaxis_column_name,
                     type='linear' if yaxis_type == 'Linear' else 'log')

    return fig

@app.callback(
    Output("distplot", "figure"),
    Input('xaxis-column', 'value'),
    Input('yaxis-column', 'value')
)
def display_graph(xaxis_column_name, yaxis_column_name):
    fig_go = go.Figure()
    fig_go.add_trace(go.Histogram(x=dataset[xaxis_column_name], name=xaxis_column_name))
    fig_go.add_trace(go.Histogram(x=dataset[yaxis_column_name], name=yaxis_column_name))
    # Overlay both histograms
    fig_go.update_layout(barmode='overlay')
    # Reduce opacity to see both histograms
    fig_go.update_traces(opacity=0.6)
    return fig_go

@app.callback(
    Output('boxplot', 'figure'),
    Input("dist-marginal", "value"),
    Input('xaxis-column', 'value'),
    Input('yaxis-column', 'value')
)
def another_graph(marginal, xaxis_column_name, yaxis_column_name):
    if marginal=='box':
        fig = px.box(dataset, [xaxis_column_name, yaxis_column_name])
    elif marginal=='violin':
        fig = px.violin(dataset, [xaxis_column_name, yaxis_column_name])
    return fig

# PRESENT PAGE
####################################################################################################
####################################################################################################
####################################################################################################

###### MAP

@app.callback(
    Output(component_id='map', component_property='figure'),
    [Input(component_id='severityChecklist', component_property='value')
    ]
)

def updateMapBox(severity):

        # Make the colours consistent for each type of accident
    severity_color = {'Fatal' : 'red',
                        'Serious' : 'orange',
                        'Slight' : 'yellow'}
    map_colors = {'Slight' : 'rgba(255,224,132,0.7)', 'Serious' : 'rgba(249,139,96,0.7)', 'Fatal' : 'rgba(178,34,34,0.9)'}
    legend_colors = {'Slight' : 'rgb(255,224,132)', 'Serious' : 'rgb(249,139,96)', 'Fatal' : 'rgb(178,34,34)'}
    light_style = 'mapbox://styles/srepho/cjttho6dl0hl91fmzwyicqkzf'

 
    token = 'pk.eyJ1IjoiYmxvYmJlcmlubyIsImEiOiJja3lwc3Rlb2gwNmYyMm50Z2NmYnJuZmUzIn0.enOkxCEYJ2qDj_qKkwP_Bw'
    df = pd.read_csv('data/accidents2015_V.csv')
    acc2 = df[df['Accident_Severity'].isin(severity)]
    traces = []

    # Filter the dataframe
    acc2 = df[df['Accident_Severity'].isin(severity)]

    sample =  acc2.sample(frac=0.4, replace=True, random_state=1)

    # Once trace for each severity value
    traces = []
    for sev in sorted(severity, reverse=True):
        # Scattermapbox trace for each severity
        traces.append({
                'type' : 'scattermapbox',
                'mode' : 'markers',
                'lat' : sample['Latitude'][sample['Accident_Severity'] == sev],
                'lon' : sample['Longitude'][sample['Accident_Severity'] == sev],
                'marker' : {
                    'color' : map_colors[sev],
                    'size' : sample['Number_of_Casualties'][sample['Accident_Severity'] == sev],
                
                },
                'name' : sev,
                'legendgroup' : sev,
                'showlegend' : False,
                'hoverinfo' : 'text',
                'text' : sample['Local_Authority_(District)'],
            })
        # Append a separate marker trace to show bigger markers for the legend. 
        #  The ones we're plotting on the map are too small to be of use in the legend.
        traces.append({
            'type' : 'scattermapbox',
            'mode' : 'markers',
            'lat' : [0],
            'lon' : [0],
            'marker' : {
                'color' : severity_color[sev],
                'size' : 12,
            },
            'name' : sev,
            'legendgroup' : sev,
            
        })
    layout = {
        'height' : 550,
        'width' : 400,
        'paper_bgcolor' : 'rgba(0,0,0,0)', 
        'autosize' : True,
        'hovermode' : 'closest',
        'legend_tracegroupgap' : 0,
        'mapbox' : {
            'accesstoken' : token,
            'center' : {
                'lat' : 54.7,
                'lon' : -4.2
            },
            'zoom' : 4.5,
            'style' : light_style,   
        },
        'margin' : {'t' : 0,
                   'b' : 0,
                   'l' : 0,
                   'r' : 0},
        'legend' : {  
            'font' : {'color' : 'black', 'size' : 10},
             'orientation' : 'h',
             'x' : 0,
             'y' : 1,
             'yanchor' : 'bottom',
             'xanchor' : 'left',
             'traceorder' : 'reversed',
        }
    }
    config = {'displayModeBar': True,'displaylogo': False, 'modeBarButtonsToRemove': ['lasso2d'], 'scrollZoom': True}
    fig = dict(data=traces, layout=layout, config = config) 
    return fig