import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
import pandas as pd
import numpy as np
import dash
import dash_table
from dash_table.Format import Format, Group
import dash_table.FormatTemplate as FormatTemplate
from datetime import datetime as dt
from app import app

####################################################################################################
# 000 - FORMATTING INFO
####################################################################################################
## DATA

csvLoc = 'data/accidents2015_V.csv'
acc = pd.read_csv(csvLoc, index_col = 0).dropna(how='any', axis = 0)
# Remove observations where speed limit is 0 or 10. There's only three and it adds a lot of 
#  complexity to the bar chart for no material benefit
acc = acc[~acc['Speed_limit'].isin([0, 10])]
# Create an hour column
acc['Hour'] = acc['Time'].apply(lambda x: int(x[:2]))

### data 2
dataset = pd.read_csv('data/2015data.csv')
dataset_copy = pd.read_csv('data/2015data.csv')

all_variables= dataset.columns.unique()
all_forced_binary_variables = []
all_binary_variables = []
all_continuous_variables = []

#remove ?
for variable_in_question in all_variables:
    dataset = dataset[dataset[variable_in_question] != '?']

#take continious var
for variable_in_question in all_variables:
    if dataset[variable_in_question].dtypes == (np.int64 or np.int32 or np.int8 or np.float_) :
        values, counts = np.unique(dataset[variable_in_question], return_counts=True)
        if (len(values)<5 and len(values)>2):
            try:
                all_forced_binary_variables.append(variable_in_question)
                index_most_occuring = np.where(counts == max(counts))
                binary_value_1 = values[index_most_occuring][0]
                new_counts = np.delete(counts, np.where(counts == max(counts)))
                new_values = np.delete(values, np.where(values == binary_value_1))
                index_second_most_occuring = np.where(new_counts == max(new_counts))
                binary_value_2 = new_values[index_most_occuring][0]
                binary_variables = [binary_value_1, binary_value_2]
                dataset = dataset[dataset[variable_in_question].isin(binary_variables)]
                all_forced_binary_variables.append(variable_in_question)
            except Exception:
                continue
            finally:
                continue
        elif (len(values)>5):
            all_continuous_variables.append(variable_in_question)
        elif (len(values) == 2):
            all_binary_variables.append(variable_in_question)
        else:
            continue
    else:
        continue
####################### Corporate css formatting
corporate_colors = {
    'dark-blue-grey' : 'rgb(62, 64, 76)',
    'medium-blue-grey' : 'rgb(77, 79, 91)',
    'superdark-green' : 'rgb(41, 56, 55)',
    'dark-green' : 'rgb(57, 81, 85)',
    'medium-green' : 'rgb(93, 113, 120)',
    'light-green' : 'rgb(186, 218, 212)',
    'pink-red' : 'rgb(255, 101, 131)',
    'dark-pink-red' : 'rgb(247, 80, 99)',
    'white' : 'rgb(251, 251, 252)',
    'light-grey' : 'rgb(208, 206, 206)'
}

externalgraph_rowstyling = {
    'margin-left' : '15px',
    'margin-right' : '15px'
}

externalgraph_colstyling = {
    'border-radius' : '10px',
    'border-style' : 'solid',
    'border-width' : '1px',
    'border-color' : corporate_colors['superdark-green'],
    'background-color' : corporate_colors['superdark-green'],
    'box-shadow' : '0px 0px 17px 0px rgba(186, 218, 212, .5)',
    'padding-top' : '10px'
}

filterdiv_borderstyling = {
    'border-radius' : '0px 0px 10px 10px',
    'border-style' : 'solid',
    'border-width' : '1px',
    'border-color' : corporate_colors['light-green'],
    'background-color' : corporate_colors['light-green'],
    'box-shadow' : '2px 5px 5px 1px rgba(255, 101, 131, .5)'
    }

navbarcurrentpage = {
    'text-decoration' : 'underline',
    'text-decoration-color' : corporate_colors['pink-red'],
    'text-shadow': '0px 0px 1px rgb(251, 251, 252)'
    }

recapdiv = {
    'border-radius' : '10px',
    'border-style' : 'solid',
    'border-width' : '1px',
    'border-color' : 'rgb(251, 251, 252, 0.1)',
    'margin-left' : '15px',
    'margin-right' : '15px',
    'margin-top' : '15px',
    'margin-bottom' : '15px',
    'padding-top' : '5px',
    'padding-bottom' : '5px',
    'background-color' : 'rgb(251, 251, 252, 0.1)'
    }

recapdiv_text = {
    'text-align' : 'left',
    'font-weight' : '350',
    'color' : corporate_colors['white'],
    'font-size' : '1.5rem',
    'letter-spacing' : '0.04em'
    }

####################### Corporate chart formatting

corporate_title = {
    'font' : {
        'size' : 16,
        'color' : corporate_colors['white']}
}

corporate_xaxis = {
    'showgrid' : False,
    'linecolor' : corporate_colors['light-grey'],
    'color' : corporate_colors['light-grey'],
    'tickangle' : 315,
    'titlefont' : {
        'size' : 12,
        'color' : corporate_colors['light-grey']},
    'tickfont' : {
        'size' : 11,
        'color' : corporate_colors['light-grey']},
    'zeroline': False
}

corporate_yaxis = {
    'showgrid' : True,
    'color' : corporate_colors['light-grey'],
    'gridwidth' : 0.5,
    'gridcolor' : corporate_colors['dark-green'],
    'linecolor' : corporate_colors['light-grey'],
    'titlefont' : {
        'size' : 12,
        'color' : corporate_colors['light-grey']},
    'tickfont' : {
        'size' : 11,
        'color' : corporate_colors['light-grey']},
    'zeroline': False
}

corporate_font_family = 'Dosis'

corporate_legend = {
    'orientation' : 'h',
    'yanchor' : 'bottom',
    'y' : 1.01,
    'xanchor' : 'right',
    'x' : 1.05,
	'font' : {'size' : 9, 'color' : corporate_colors['light-grey']}
} # Legend will be on the top right, above the graph, horizontally

corporate_margins = {'l' : 5, 'r' : 5, 't' : 45, 'b' : 15}  # Set top margin to in case there is a legend

corporate_layout = go.Layout(
    font = {'family' : corporate_font_family},
    title = corporate_title,
    title_x = 0.5, # Align chart title to center
    paper_bgcolor = 'rgba(0,0,0,0)',
    plot_bgcolor = 'rgba(0,0,0,0)',
    xaxis = corporate_xaxis,
    yaxis = corporate_yaxis,
    height = 270,
    legend = corporate_legend,
    margin = corporate_margins
    )

####################################################################################################
# 000 - DATA MAPPING
####################################################################################################


####################################################################################################
# 000 - IMPORT DATA
####################################################################################################

################################################################################################################################################## SET UP END

####################################################################################################
# 000 - DEFINE REUSABLE COMPONENTS AS FUNCTIONS
####################################################################################################

#####################
# Header with logo
def get_header():

    header = html.Div([

        html.Div([], className = 'col-2'), #Same as img width, allowing to have the title centrally aligned

        html.Div([
            html.H1(children='Car Insurance Dashboard',
                    style = {'textAlign' : 'center'}
            )],
            className='col-8',
            style = {'padding-top' : '1%'}
        ),

        html.Div([
            html.Img(
                    src = app.get_asset_url('logo.png'),
                    height = '43 px',
                    width = 'auto')
            ],
            className = 'col-2',
            style = {
                    'align-items': 'center',
                    'padding-top' : '1%',
                    'height' : 'auto'})

        ],
        className = 'row',
        style = {'height' : '4%',
                'background-color' : corporate_colors['superdark-green']}
        )

    return header

#####################
# Nav bar
def get_navbar(p = 'sales'):

    navbar_explore = html.Div([

        html.Div([], className = 'col-3'),

        html.Div([
            dcc.Link(
                html.H4(children = 'Explore',
                        style = navbarcurrentpage),
                href='/apps/explore'
                )
        ],
        className='col-2'),

        html.Div([
            dcc.Link(
                html.H4(children = 'Analyze'),
                href='/apps/analyze'
                )
        ],
        className='col-2'),

        html.Div([
            dcc.Link(
                html.H4(children = 'Present'),
                href='/apps/present'
                )
        ],
        className='col-2'),

        html.Div([], className = 'col-3')

    ],
    className = 'row',
    style = {'background-color' : corporate_colors['dark-green'],
            'box-shadow': '2px 5px 5px 1px rgba(255, 101, 131, .5)'}
    )

    navbar_analyze = html.Div([

        html.Div([], className = 'col-3'),

        html.Div([
            dcc.Link(
                html.H4(children = 'Explore'),
                href='/apps/explore'
                )
        ],
        className='col-2'),

        html.Div([
            dcc.Link(
                html.H4(children = 'Analyze',
                        style = navbarcurrentpage),
                href='/apps/analyze'
                )
        ],
        className='col-2'),

        html.Div([
            dcc.Link(
                html.H4(children = 'Present'),
                href='/apps/present'
                )
        ],
        className='col-2'),

        html.Div([], className = 'col-3')

    ],
    className = 'row',
    style = {'background-color' : corporate_colors['dark-green'],
            'box-shadow': '2px 5px 5px 1px rgba(255, 101, 131, .5)'}
    )

    navbar_present = html.Div([

        html.Div([], className = 'col-3'),

        html.Div([
            dcc.Link(
                html.H4(children = 'Explore'),
                href='/apps/explore'
                )
        ],
        className='col-2'),

        html.Div([
            dcc.Link(
                html.H4(children = 'Analyze'),
                href='/apps/analyze'
                )
        ],
        className='col-2'),

        html.Div([
            dcc.Link(
                html.H4(children = 'Present',
                        style = navbarcurrentpage),
                href='/apps/present'
                )
        ],
        className='col-2'),

        html.Div([], className = 'col-3')

    ],
    className = 'row',
    style = {'background-color' : corporate_colors['dark-green'],
            'box-shadow': '2px 5px 5px 1px rgba(255, 101, 131, .5)'}
    )

    if p == 'explore':
        return navbar_explore
    elif p == 'analyze':
        return navbar_analyze
    else:
        return navbar_present

#####################
# Empty row

def get_emptyrow(h='45px'):
    """This returns an empty row of a defined height"""

    emptyrow = html.Div([
        html.Div([
            html.Br()
        ], className = 'col-12')
    ],
    className = 'row',
    style = {'height' : h})

    return emptyrow

####################################################################################################
# 001 - SALES
####################################################################################################

explore = html.Div([

    #####################
    #Row 1 : Header
    get_header(),

    #####################
    #Row 2 : Nav bar
    get_navbar('explore'),

    #####################
    #Row 3 : Filters
    html.Div([ # External row

        html.Div([ # External 12-column

            html.Div([ # Internal row

                #Internal columns
                html.Div([
                ],
                className = 'col-2'), # Blank 2 columns

                #Filter pt 1
                html.Div([
                html.H5(
                    children='Variables',
                    style = {'text-align' : 'left', 'color' : corporate_colors['medium-blue-grey']}
                ),

            html.Div([ 'Select the variable for the X axis: ',
            dcc.Dropdown(
                id='xaxis-column',
                options=[{'label': i, 'value': i} for i in all_continuous_variables],
                value='Number_of_Casualties'
            ),
            dcc.RadioItems(
                id='xaxis-type',
                options=[{'label': i, 'value': i} for i in ['Linear', 'Log']],
                value='Linear',
                labelStyle={'display': 'inline-block'}
            )
        ], style={'width': '48%', 'display': 'inline-block'}),

        html.Div([ 'Select the variable for the Y axis: ',
            dcc.Dropdown(
                id='yaxis-column',
                options=[{'label': i, 'value': i} for i in all_continuous_variables],
                value='Number_of_Casualties'
            ),
            dcc.RadioItems(
                id='yaxis-type',
                options=[{'label': i, 'value': i} for i in ['Linear', 'Log']],
                value='Linear',
                labelStyle={'display': 'inline-block'}
            )
            ], style={'width': '48%', 'float': 'right', 'display': 'inline-block'})
                        
    
                ],
                className = 'col-4'), # Filter part 1

                #Filter pt 2
                html.Div([

                    html.Div([
                        html.H5(
                            children='Number of casualties',
                            style = {'text-align' : 'left', 'color' : corporate_colors['medium-blue-grey']}
                        ),
                        #Number of casualties slider
                        html.Div([
                                        dcc.Slider(
                            id='Number_of_Casualties',
                            min=dataset['Number_of_Casualties'].min(),
                            max=dataset['Number_of_Casualties'].max(),
                            value= 2,
                            marks={str(year): str(year) for year in dataset['Number_of_Casualties'].unique()},
                            step=None
                        )
                            ],
                            style = {'width' : '70%', 'margin-top' : '5px'}),
                        #Vioilin/box 
                        html.Div([
                            dcc.RadioItems(
                                id='dist-marginal',
                                options=[{'label': x, 'value': x}
                                        for x in ['box', 'violin']],
                                value='box')
                            ],
                            style = {'width' : '70%', 'margin-top' : '5px'})
                    ],
                    style = {'margin-top' : '10px',
                            'margin-bottom' : '5px',
                            'text-align' : 'left',
                            'paddingLeft': 5})

                ],
                className = 'col-4'), # Filter part 2

                html.Div([
                ],
                className = 'col-2') # Blank 2 columns


            ],
            className = 'row') # Internal row

        ],
        className = 'col-12',
        style = filterdiv_borderstyling) # External 12-column

    ],
    className = 'row sticky-top'), # External row

    #####################
    #Row 4
    get_emptyrow(),

    #####################
    #Row 5 : Charts
    html.Div([ # External row

        html.Div([
        ],
        className = 'col-1'), # Blank 1 column

        html.Div([ # External 10-column

            html.H2(children = "Visualizations",
                    style = {'color' : corporate_colors['white']}),

            html.Div([ # Internal row - RECAPS

                html.Div([],className = 'col-4'), # Empty column

                html.Div([
                    dash_table.DataTable(
                        id='recap-table',
                        style_header = {
                            'backgroundColor': 'transparent',
                            'fontFamily' : corporate_font_family,
                            'font-size' : '1rem',
                            'color' : corporate_colors['light-green'],
                            'border': '0px transparent',
                            'textAlign' : 'center'},
                        style_cell = {
                            'backgroundColor': 'transparent',
                            'fontFamily' : corporate_font_family,
                            'font-size' : '0.85rem',
                            'color' : corporate_colors['white'],
                            'border': '0px transparent',
                            'textAlign' : 'center'},
                        cell_selectable = False,
                        column_selectable = False
                    )
                ],
                className = 'col-4'),

                html.Div([],className = 'col-4') # Empty column

            ],
            className = 'row',
            style = recapdiv
            ), # Internal row - RECAPS

            html.Div([ # Internal row

                # Chart Column
                html.Div([
                    dcc.Graph(
                        id='distplot')
                ],
                className = 'col-4'),

                # Chart Column
                html.Div([
                    dcc.Graph(id='boxplot'),
                    html.P("Select Distribution:"),
                    dcc.RadioItems(
                        id='dist-marginal',
                        options=[{'label': x, 'value': x}
                                for x in ['box', 'violin']],
                        value='box')
                ],
                className = 'col-4'),

                # Chart Column
                html.Div([
                    dcc.Graph(
                        id='sales-weekly-heatmap')
                ],
                className = 'col-4')

            ],
            className = 'row'), # Internal row

            html.Div([ # Internal row

                # Chart Column
                html.Div([
                    dcc.Graph(
                        id='')
                ],
                className = 'col-4'),

                # Chart Column
                html.Div([
                    dcc.Graph(
                        id='')
                ],
                className = 'col-4'),

                # Chart Column
                html.Div([
                    dcc.Graph(
                        id='')
                ],
                className = 'col-4')

            ],
            className = 'row') # Internal row


        ],
        className = 'col-10',
        style = externalgraph_colstyling), # External 10-column

        html.Div([
        ],
        className = 'col-1'), # Blank 1 column

    ],
    className = 'row',
    style = externalgraph_rowstyling
    ), # External row

])

####################################################################################################
# 002 - Page 2
####################################################################################################

analyze = html.Div([

    #####################
    #Row 1 : Header
    get_header(),

    #####################
    #Row 2 : Nav bar
    get_navbar('analyze'),

        html.Div([

        html.Div([
            dcc.Dropdown(
                id='xaxis-column',
                options=[{'label': i, 'value': i} for i in all_continuous_variables],
                value='Number_of_Casualties'
            ),
            dcc.RadioItems(
                id='xaxis-type',
                options=[{'label': i, 'value': i} for i in ['Linear', 'Log']],
                value='Linear',
                labelStyle={'display': 'inline-block'}
            )
        ], style={'width': '48%', 'display': 'inline-block'}),

        html.Div([
            dcc.Dropdown(
                id='yaxis-column',
                options=[{'label': i, 'value': i} for i in all_continuous_variables],
                value='Number_of_Casualties'
            ),
            dcc.RadioItems(
                id='yaxis-type',
                options=[{'label': i, 'value': i} for i in ['Linear', 'Log']],
                value='Linear',
                labelStyle={'display': 'inline-block'}
            )
        ], style={'width': '48%', 'float': 'right', 'display': 'inline-block'})
    ]),


    html.Div([
        dcc.Graph(id='indicator-graphic'),

        dcc.Slider(
            id='Number_of_Casualties',
            min=dataset['Number_of_Casualties'].min(),
            max=dataset['Number_of_Casualties'].max(),
            value= 2,
            marks={str(year): str(year) for year in dataset['Number_of_Casualties'].unique()},
            step=None
        )
    ]),

    html.Div([
        html.Div([
            dcc.Graph(id="distplot")
        ], style={'width': '60%', 'display': 'inline-block'}),
        html.Div([
            dcc.Graph(id='boxplot'),
            html.P("Select Distribution:"),
            dcc.RadioItems(
                id='dist-marginal',
                options=[{'label': x, 'value': x}
                         for x in ['box', 'violin']],
                value='box')
        ], style={'width': '40%', 'display': 'inline-block'}),

    ]),
])


####################################################################################################
# 003 - Page 3
####################################################################################################

present = html.Div([

    #####################
    #Row 1 : Header
    get_header(),

    #####################
    #Row 2 : Nav bar
    get_navbar('present'),

    #####################
    #Row 3 : Filters
    html.Div([ # External row

        dcc.Checklist( # Checklist for the three different severity values
                options=[
                    {'label': sev, 'value': sev} for sev in acc['Accident_Severity'].unique()
                ],
                value=[sev for sev in acc['Accident_Severity'].unique()],
                labelStyle={
                    'display': 'inline-block',
                    'paddingRight' : 10,
                    'paddingLeft' : 10,
                    'paddingBottom' : 5,
                    },
                id="severityChecklist")

    ],
    className = 'row sticky-top'), # External row

    #####################
    #Row 4
    get_emptyrow(),

    #####################
    #Row 5 : Charts
    html.Div([ # External row

        dcc.Graph(id="map") # Holds the map in a div to apply styling to it
            
        ],
        style={
            "width" : '40%', 
            'float' : 'right', 
            'display' : 'inline-block', 
            'paddingRight' : 50, 
            'paddingLeft' : 10,
            'boxSizing' : 'border-box',
            'fontFamily' : "Arial"
            })

    ])