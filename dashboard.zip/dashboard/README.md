# Corporate-Dashboard
Business-like dashboard based on plotly Dash, written in Python and including layout customisations with .css bootstrap.
The app has been deployed on Heroku and is visible here: https://corporate-dash.herokuapp.com/
